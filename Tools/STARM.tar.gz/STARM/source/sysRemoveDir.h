#ifndef DEF_sysRemoveDir
#define DEF_sysRemoveDir

#include <string>

void sysRemoveDir(std::string dirName);

#endif